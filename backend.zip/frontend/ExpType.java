package frontend;

public enum ExpType {
    NULL,//0
    INT, CHAR,//1
    INTARRAY,//2
    CHARARRAY//3
}
