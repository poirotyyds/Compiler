package frontend.symbolTableManagement;

public class ArraySymbol extends Symbol{
    public ArraySymbol(int id, int tableId, String name, int type, int bType, boolean isCon) {
        super(id, tableId, name, type, bType, isCon);
    }
}
