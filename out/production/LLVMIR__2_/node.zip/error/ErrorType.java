package error;

public enum ErrorType {
    a, b, c, d, e, f, g, h, i, j, k, l, m
}
