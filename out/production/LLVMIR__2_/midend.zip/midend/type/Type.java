package midend.type;

public abstract class Type {
    public abstract int getSize();

}
